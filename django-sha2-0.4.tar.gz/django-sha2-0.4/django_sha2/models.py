"""Make sure django.contrib.auth monkeypatching happens on load."""
from django_sha2 import auth
