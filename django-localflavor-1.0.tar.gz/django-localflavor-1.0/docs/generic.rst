Generic helpers
===============

Forms
-----

.. automodule:: localflavor.generic.forms
    :members:
