Iceland (``is``)
================

Forms
-----

.. automodule:: localflavor.is_.forms
    :members:

Data
----

.. autodata:: localflavor.is_.is_postalcodes.IS_POSTALCODES
