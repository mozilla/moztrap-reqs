Poland (``pl``)
===============

Forms
-----

.. automodule:: localflavor.pl.forms
    :members:

Data
----

.. autodata:: localflavor.pl.pl_administrativeunits.ADMINISTRATIVE_UNIT_CHOICES

.. autodata:: localflavor.pl.pl_voivodeships.VOIVODESHIP_CHOICES
