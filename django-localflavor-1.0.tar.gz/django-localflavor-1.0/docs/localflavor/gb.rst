Great Britain (``gb``)
======================

Forms
-----

.. automodule:: localflavor.gb.forms
    :members:

Data
----

.. autodata:: localflavor.gb.gb_regions.ENGLAND_REGION_CHOICES

.. autodata:: localflavor.gb.gb_regions.NORTHERN_IRELAND_REGION_CHOICES

.. autodata:: localflavor.gb.gb_regions.WALES_REGION_CHOICES

.. autodata:: localflavor.gb.gb_regions.SCOTTISH_REGION_CHOICES

.. autodata:: localflavor.gb.gb_regions.GB_NATIONS_CHOICES

.. autodata:: localflavor.gb.gb_regions.GB_REGION_CHOICES
