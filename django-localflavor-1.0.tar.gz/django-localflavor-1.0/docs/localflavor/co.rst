Columbia (``co``)
=================

Forms
-----

.. automodule:: localflavor.co.forms
    :members:

Data
----

.. autodata:: localflavor.co.co_departments.DEPARTMENT_CHOICES
