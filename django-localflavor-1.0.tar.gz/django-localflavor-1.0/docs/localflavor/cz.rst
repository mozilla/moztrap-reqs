Czech Republic (``cz``)
=======================

Forms
-----

.. automodule:: localflavor.cz.forms
    :members:

Data
----

.. autodata:: localflavor.cz.cz_regions.REGION_CHOICES
