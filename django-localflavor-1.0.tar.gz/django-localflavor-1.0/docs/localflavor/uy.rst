Urguay (``uy``)
===============

Forms
-----

.. automodule:: localflavor.uy.forms
    :members:

Utilities
---------

.. automodule:: localflavor.uy.util
    :members:

Data
----

.. autodata:: localflavor.uy.uy_departments.DEPARTMENT_CHOICES
