Romania (``ro``)
================

Forms
-----

.. automodule:: localflavor.ro.forms
    :members:

Data
----

.. autodata:: localflavor.ro.ro_counties.COUNTIES_CHOICES
