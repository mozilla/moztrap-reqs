Lithuania (``lt``)
==================

Forms
-----

.. automodule:: localflavor.lt.forms
    :members:

Data
----

.. autodata:: localflavor.lt.lt_choices.COUNTY_CHOICES

.. autodata:: localflavor.lt.lt_choices.MUNICIPALITY_CHOICES
