France (``fr``)
===============

Forms
-----

.. automodule:: localflavor.fr.forms
    :members:

Data
----

.. autodata:: localflavor.fr.fr_department.DEPARTMENT_CHOICES_PER_REGION

.. autodata:: localflavor.fr.fr_department.DEPARTMENT_CHOICES

.. autodata:: localflavor.fr.fr_region.REGION_CHOICES

