Russia (``ru``)
===============

Forms
-----

.. automodule:: localflavor.ru.forms
    :members:

Data
----

.. autodata:: localflavor.ru.ru_regions.RU_COUNTY_CHOICES

.. autodata:: localflavor.ru.ru_regions.RU_REGIONS_CHOICES
