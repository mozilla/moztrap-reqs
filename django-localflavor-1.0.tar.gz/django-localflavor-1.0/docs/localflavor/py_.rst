Paraguay (``py``)
=================

Forms
-----

.. automodule:: localflavor.py_.forms
    :members:

Data
----

.. autodata:: localflavor.py_.py_department.DEPARTMENT_CHOICES

.. autodata:: localflavor.py_.py_department.DEPARTMENT_ROMAN_CHOICES
