Australia (``au``)
==================

Forms
-----

.. automodule:: localflavor.au.forms
    :members:

Models
------

.. automodule:: localflavor.au.models
    :members:
    :undoc-members:

Data
----

.. autodata:: localflavor.au.au_states.STATE_CHOICES
