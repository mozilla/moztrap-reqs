Argentina (``ar``)
==================

.. automodule:: localflavor.ar.forms
    :members:

.. autodata:: localflavor.ar.ar_provinces.PROVINCE_CHOICES
