China (``cn``)
==============

Forms
-----

.. automodule:: localflavor.cn.forms
    :members:

Data
----

.. autodata:: localflavor.cn.cn_provinces.CN_PROVINCE_CHOICES
