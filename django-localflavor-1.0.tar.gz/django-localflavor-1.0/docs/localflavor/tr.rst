Turkey (``tr``)
===============

Forms
-----

.. automodule:: localflavor.tr.forms
    :members:

Data
----

.. autodata:: localflavor.tr.tr_provinces.PROVINCE_CHOICES
