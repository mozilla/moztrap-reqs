Indonesia (``id``)
==================

Forms
-----

.. automodule:: localflavor.id_.forms
    :members:

Data
----

.. autodata:: localflavor.id_.id_choices.PROVINCE_CHOICES

.. autodata:: localflavor.id_.id_choices.LICENSE_PLATE_PREFIX_CHOICES
