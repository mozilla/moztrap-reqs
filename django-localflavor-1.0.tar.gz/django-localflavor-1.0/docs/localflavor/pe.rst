Peru (``pe``)
=============

Forms
-----

.. automodule:: localflavor.pe.forms
    :members:

Data
----

.. autodata:: localflavor.pe.pe_region.REGION_CHOICES
