Kuwait (``kw``)
===============

Forms
-----

.. automodule:: localflavor.kw.forms
    :members:
