Canada (``ca``)
===============

Forms
-----

.. automodule:: localflavor.ca.forms
    :members:

Data
----

.. autodata:: localflavor.ca.ca_provinces.PROVINCE_CHOICES

.. autodata:: localflavor.ca.ca_provinces.PROVINCES_NORMALIZED
