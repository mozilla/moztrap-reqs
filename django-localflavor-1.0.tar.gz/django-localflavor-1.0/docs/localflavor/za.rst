South Africa (``za``)
=====================

Forms
-----

.. automodule:: localflavor.za.forms
    :members:

Data
----

.. autodata:: localflavor.za.za_provinces.PROVINCE_CHOICES
