Croatia (``hr``)
================

Forms
-----

.. automodule:: localflavor.hr.forms
    :members:

Data
----

.. autodata:: localflavor.hr.hr_choices.HR_COUNTY_CHOICES

.. autodata:: localflavor.hr.hr_choices.HR_LICENSE_PLATE_PREFIX_CHOICES

.. autodata:: localflavor.hr.hr_choices.HR_PHONE_NUMBER_PREFIX_CHOICES
