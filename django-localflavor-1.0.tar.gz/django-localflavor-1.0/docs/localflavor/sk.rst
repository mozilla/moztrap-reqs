Slovakia (``sk``)
=================

Forms
-----

.. automodule:: localflavor.sk.forms
    :members:

Data
----

.. autodata:: localflavor.sk.sk_districts.DISTRICT_CHOICES

.. autodata:: localflavor.sk.sk_regions.REGION_CHOICES
