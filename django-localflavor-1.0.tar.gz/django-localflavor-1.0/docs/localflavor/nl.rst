The Netherlands (``nl``)
========================

Forms
-----

.. automodule:: localflavor.nl.forms
    :members:

Data
----

.. autodata:: localflavor.nl.nl_provinces.PROVINCE_CHOICES
