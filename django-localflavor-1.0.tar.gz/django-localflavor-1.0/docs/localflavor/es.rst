Spain (``es``)
==============

Forms
-----

.. automodule:: localflavor.es.forms
    :members:

Data
----

.. autodata:: localflavor.es.es_provinces.PROVINCE_CHOICES

.. autodata:: localflavor.es.es_regions.REGION_CHOICES
