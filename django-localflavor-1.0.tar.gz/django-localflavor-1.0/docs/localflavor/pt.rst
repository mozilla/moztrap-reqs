Portugal (``pt``)
=================

Forms
-----

.. automodule:: localflavor.pt.forms
    :members:

Data
----

.. autodata:: localflavor.pt.pt_regions.REGION_CHOICES
