Ecuador (``ec``)
================

Forms
-----

.. automodule:: localflavor.ec.forms
    :members:

Data
----

.. autodata:: localflavor.ec.ec_provinces.PROVINCE_CHOICES
