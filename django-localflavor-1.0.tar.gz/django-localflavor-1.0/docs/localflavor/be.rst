Belgium (``be``)
================

Forms
-----

.. automodule:: localflavor.be.forms
    :members:

Data
----

.. autodata:: localflavor.be.be_provinces.PROVINCE_CHOICES

.. autodata:: localflavor.be.be_regions.REGION_CHOICES
