Brazil (``br``)
===============

Forms
-----

.. automodule:: localflavor.br.forms
    :members:

Data
----

.. autodata:: localflavor.br.br_states.STATE_CHOICES
