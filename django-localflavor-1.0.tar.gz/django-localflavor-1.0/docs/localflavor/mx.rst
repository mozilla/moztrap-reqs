Mexico (``mx``)
===============

Forms
-----

.. automodule:: localflavor.mx.forms
    :members:

Models
------

.. automodule:: localflavor.mx.models
    :members:

Data
----

.. autodata:: localflavor.mx.mx_states.STATE_CHOICES
