India (``in``)
==============

Forms
-----

.. automodule:: localflavor.in_.forms
    :members:

Data
----

.. autodata:: localflavor.in_.in_states.STATE_CHOICES

.. autodata:: localflavor.in_.in_states.STATES_NORMALIZED
