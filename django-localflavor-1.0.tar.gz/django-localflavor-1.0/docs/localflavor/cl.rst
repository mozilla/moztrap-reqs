Chile (``cl``)
==============

Forms
-----

.. automodule:: localflavor.cl.forms
    :members:

Data
----

.. autodata:: localflavor.cl.cl_regions.REGION_CHOICES
