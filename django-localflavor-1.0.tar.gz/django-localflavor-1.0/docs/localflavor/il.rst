Israel (``il``)
===============

Forms
-----

.. automodule:: localflavor.il.forms
    :members:
