Switzerland (``ch``)
====================

Forms
-----

.. automodule:: localflavor.ch.forms
    :members:

Data
----

.. autodata:: localflavor.ch.ch_states.STATE_CHOICES
