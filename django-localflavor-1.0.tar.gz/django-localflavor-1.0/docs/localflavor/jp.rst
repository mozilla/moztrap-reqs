Japan (``jp``)
==============

Forms
-----

.. automodule:: localflavor.jp.forms
    :members:

Data
----

.. autodata:: localflavor.jp.jp_prefectures.JP_PREFECTURES
