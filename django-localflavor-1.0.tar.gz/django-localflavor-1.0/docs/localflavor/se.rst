Sweden (``se``)
===============

Forms
-----

.. automodule:: localflavor.se.forms
    :members:

Utilities
---------

.. automodule:: localflavor.se.utils
    :members:

Data
----

.. autodata:: localflavor.se.se_counties.COUNTY_CHOICES
