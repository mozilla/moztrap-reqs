Ireland (``ie``)
================

Forms
-----

.. automodule:: localflavor.ie.forms
    :members:

Data
----

.. autodata:: localflavor.ie.ie_counties.IE_COUNTY_CHOICES
