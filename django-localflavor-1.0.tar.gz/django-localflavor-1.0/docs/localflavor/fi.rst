Finnland (``fi``)
=================

Forms
-----

.. automodule:: localflavor.fi.forms
    :members:

Data
----

.. autodata:: localflavor.fi.fi_municipalities.MUNICIPALITY_CHOICES
