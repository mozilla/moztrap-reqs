Germany (``de``)
================

Forms
-----

.. automodule:: localflavor.de.forms
    :members:

Data
----

.. autodata:: localflavor.de.de_states.STATE_CHOICES
