Norway (``no``)
===============

Forms
-----

.. automodule:: localflavor.no.forms
    :members:

Data
----

.. autodata:: localflavor.no.no_municipalities.MUNICIPALITY_CHOICES
