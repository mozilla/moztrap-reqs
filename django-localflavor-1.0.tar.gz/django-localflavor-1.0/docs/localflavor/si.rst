Slovenia (``si``)
=================

Forms
-----

.. automodule:: localflavor.si.forms
    :members:

Data
----

.. autodata:: localflavor.si.si_postalcodes.SI_POSTALCODES
