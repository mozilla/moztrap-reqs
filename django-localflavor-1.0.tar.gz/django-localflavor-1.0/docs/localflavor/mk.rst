Macedonia (``mk``)
==================

Forms
-----

.. automodule:: localflavor.mk.forms
    :members:

Models
------

.. automodule:: localflavor.mk.models
    :members:

Data
----

.. autodata:: localflavor.mk.mk_choices.MK_MUNICIPALITIES
