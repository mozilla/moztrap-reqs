Italy (``it``)
==============

Forms
-----

.. automodule:: localflavor.it.forms
    :members:

Utilities
---------

.. automodule:: localflavor.it.util
    :members:

Data
----

.. autodata:: localflavor.it.it_province.PROVINCE_CHOICES

.. autodata:: localflavor.it.it_region.REGION_CHOICES
