Authors
=======

* Aaron Boman
* Adrian Holovaty
* Alex Gaynor
* Alex Hill
* Alex Zhang
* Alonisser
* Andreas Pelme
* Andres Torres Marroquin
* Andrew Godwin
* Aymeric Augustin
* Ben Davis
* Bruno M. Custódio
* Claude Paroz
* Douglas Miranda
* Erik Romijn
* Flavio Curella
* Florian Apolloner
* Gary Wilson Jr
* Gerardo Orozco
* Grzes Furga
* Honza Král
* Horst Gutmann
* Jacob Kaplan-Moss
* James Bennett
* Jannis Leidel
* Jérémie Ferry
* Jonas Ghyllebert
* Joseph Kocherhans
* Julien Phalip
* Justin Bronn
* Karen Tracey
* Luke Benstead
* Malcolm Tredinnick
* Martin Ogden
* Matias Dinota
* Olivier Sels
* Rael Max
* Ramiro Morales
* Rolf Erik Lekang
* Russell Keith-Magee
* Serafeim Papastefanos
* Sergio Oliveira
* Simon Charette
* Simonas Kazlauskas
* Stefan Kjartansson
* Thiago Avelino
* Tino de Bruijn
* Trey Hunner
* Tyler Ball
* baffolobill
* d.merc
* luyikei
* tadeo
* Łukasz Langa
