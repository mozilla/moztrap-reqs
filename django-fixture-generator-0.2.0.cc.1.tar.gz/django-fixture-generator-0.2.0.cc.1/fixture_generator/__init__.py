from fixture_generator.fixture_gen import fixture_generator

VERSION = (0, 2, 0, "cc", 1)
