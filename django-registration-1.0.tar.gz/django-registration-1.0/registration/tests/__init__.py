from registration.tests.default_backend import *
from registration.tests.forms import *
from registration.tests.models import *
from registration.tests.simple_backend import *
