class Preferences(object):
    """
    Placeholder class to which preferences properties are added
    dynamically through a signal. See models.py
    """
    pass

preferences = Preferences()
