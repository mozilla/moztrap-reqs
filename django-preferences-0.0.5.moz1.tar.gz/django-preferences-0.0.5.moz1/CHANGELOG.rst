Changelog
=========

0.0.5 (2011-08-17)
------------------
#. Added sites support.
#. Added unittests.

0.0.4 (2011-08-11)
------------------
#. Cleanup. Docs polish.

0.0.3
-----
#. Spelling correction, thanks tiktuk.

0.0.2
-----
#. Doc update to indicate importance of placing url include before admin url include.

0.0.1
-----
#. First super alpha release.

