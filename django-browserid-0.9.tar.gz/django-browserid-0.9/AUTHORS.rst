``django-browserid`` is written and maintained by various contributors:

Current Maintainer
``````````````````

- Michael Kelly <mkelly@mozilla.com>

Previous Maintainers
````````````````````

- Paul Osman
- Austin King
- Ben Adida


Patches and Suggestions
```````````````````````

- Thomas Grainger
- Owen Coutts
- Francois Marier
- Andy McKay
- Giorgos Logiotatidis
- Alexis Metaireau
- Rob Hudson
- Ross Bruniges
- Les Orchard
- Charlie DeTar
- Luke Crouch
- shaib
- Kumar McMillan
- Carl Meyer
- ptgolden
- Will Kahn-Greene
- Allen Short
- meehow
- Greg Koberger
- Niran Babalola
- callmekatootie
- Paul Mclanahan
- JR Conlin
- Prasoon Shukla
- Peter Bengtsson
- Javed Khan
- Kalail (Kashif Malik)
- Richard Mansfield
- Francesco Pischedda
