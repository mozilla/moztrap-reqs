from __future__ import unicode_literals


__author__ = 'Daniel Lindsley, Cody Soyland, Matt Croydon, Josh Bohde & Issac Kelly'
__version__ = (0, 10, 0)
